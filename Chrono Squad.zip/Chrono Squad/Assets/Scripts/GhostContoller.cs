﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GhostContoller : MonoBehaviour {

    Animator anim;
    public bool saved;
    public bool dead;
    public bool died_once;
    GameObject deathBullet;
    public bool already_died;
    RewindThis rewind_script;

	// Use this for initialization
	void Start () {
        anim = gameObject.GetComponent<Animator>();
        dead = false;
        saved = false;
        already_died = false;
        rewind_script = gameObject.GetComponent<RewindThis>();
	}
	
	// Update is called once per frame
	void Update () {
        if(Input.GetKey(KeyCode.E)){
            if(!dead){
                rewindTrigger();
            }
        }
		
	}

    void OnTriggerEnter2D(Collider2D col){
        //Debug.Log(col.gameObject.tag);
        if(Input.GetKey(KeyCode.E)){

        }
        else
        {
            if (col.gameObject.tag == "EnemyBullet")
            {
                if (!already_died)
                {
                    if (!dead)
                    {
                        deathBullet = col.gameObject;
                        deathTrigger();
                    }
                }
                else
                {
//                    if (deathBullet != null)
//                    {
//                        if (col.gameObject.name.Equals(deathBullet.name))
//                        {
                            deathTrigger();
//                        }
//                    }
                }

            }
            else if (saved == true && col.gameObject.tag == "Player")
            {
                try{
                    col.gameObject.GetComponent<Player1Controller>().DoubleUp();
                }catch(Exception e){
                    col.gameObject.GetComponent<Player2Controller>().DoubleUp();
                }
                gameObject.GetComponentInChildren<SpriteRenderer>().enabled = false;
                //Destroy(gameObject);
            }
        }
    }

    void onTriggerExit2D(Collider2D col){
        if (Input.GetKey(KeyCode.E))
        {
            if (col.gameObject.tag == "EnemyBullet")
            {
                if (already_died)
                {
                    if (col.gameObject.name.Equals(deathBullet.name))
                    {
                        rewindTrigger();
                    }
                }
                else
                {
                }
            }
        }

    }

    public void deathTrigger(){
        dead = true;
        saved = false;
        already_died = true;
        //anim.SetBool("save", saved);
        anim.SetBool("dead", dead);
      //  rewind_script.setObjectDeath();
    }

    public void rewindTrigger(){
        saved = false;
        //dead = false;
        anim.SetBool("save", saved);
        anim.SetBool("dead", dead);
    }

    public void Saved(){

            saved = true;
            anim.SetBool("save", saved);
            anim.SetBool("dead", dead);
    }

    public void populate(bool _already_died, GameObject _deathBullet){
        died_once = _already_died;
        deathBullet = _deathBullet;
    }

    public void setDead(bool _dead){
        if (!already_died)
        {
            if (_dead)
            {
                dead = _dead;
                already_died = true;
            }
        }
        else
        {
            if (!_dead)
            {
                dead = _dead;
                already_died = false;
            }
        }
    }
       
}
