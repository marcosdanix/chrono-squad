﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player2Controller : MonoBehaviour {

	public bool facingRight = true;
	public bool jump = false;

    public float maxSpeed = 15f;
	public float speed = 100f;
    static float N_MAXSPEED = 15f;
    static float S_MAXSPEED = 5f;
    public float jumpForce;
	public Transform groundCheck;

    public float fallMultiplier = 2.5f;
    public float lowJumpMultiplier = 2f;

    public float chargeTimer = 0;
    public float maxChargeTime = 2f;

	public bool grounded = false;
    public bool dead = false;
	private Animator anim;
	private Rigidbody2D rb2d;

    //shoot
    public GameObject projectile;
    public Vector2 velocity;
    Vector2 offset;
    Vector2 current_dir= Vector2.zero;
    int rotation;
    public Quaternion rotation_vec = Quaternion.identity;
    public bool canShoot = true;
    public bool isShooting = false;
    public float firePower;

    //charge
    bool charged= false;
    public Image chargeBar;
    public bool chargedShooting = false;
    Vector2 velocity2;
    Vector2 velocity3;
    Vector2 offset2;
    Vector2 offset3;
    float reloadTimer;
    public GameObject charge_go;
    public int chargedNum = 3;
    int p1chargeNum = 10;
    int p1chargedCounter = 0;
    public float chargedCounter = 0;
    public GameObject double_d;
    public bool double_damage = false;
    public float startTimer = 0;
    public float startCharge = 1f;

    //Blocking
    public GameObject shield;
    public bool isCharging;
    public bool canShield;

    public GameObject deathBullet;

	// Use this for initialization
	void Start () {
        rb2d = gameObject.GetComponent<Rigidbody2D>();
        anim = gameObject.GetComponentInChildren<Animator>();
        chargeTimer = 0;
        reloadTimer = 0;
        maxSpeed = 15f;
        firePower = 25;
	}

    void Update ()
    {
        if (Time.timeScale == 0) {
            return;
        }

        offset = new Vector2(1.0f,1.0f);
        current_dir = Vector2.zero;

        if (Input.GetKey (KeyCode.E)) {
            return;
        }

        if (Input.GetAxis("Horizontal") < -0.1f)
        {
            transform.localScale = new Vector3(-1, 1, 1);
            current_dir += Vector2.left;
        }
        if (Input.GetAxis("Horizontal") > 0.1)
        {
            transform.localScale = new Vector3(1, 1, 1);
            current_dir += Vector2.right;
        }

        if (Input.GetAxis("Vertical") < -0.1f && !grounded)
        {
            //transform.localScale = new Vector3(1, -1, 1);
            current_dir += Vector2.down;
        }
        if (Input.GetAxis("Vertical") > 0.1)
        {
            //transform.localScale = new Vector3(1, 1, 1);
            current_dir += Vector2.up;
        }

        if (Input.GetButtonDown("Jump") && grounded)
        {
            
            rb2d.AddForce(Vector2.up * Mathf.Sqrt(-2.0f * Physics2D.gravity.y * jumpForce), ForceMode2D.Impulse);
        }


        // ATTACKING
        if (reloadTimer >= 0.1f)
        {
            canShield = true;
        }
        else{
            canShield = false;
            reloadTimer += Time.deltaTime;
        }

        if (current_dir == Vector2.zero)
        {
            current_dir = new Vector2(transform.localScale.x, 0);
        }

        rotation = (int)Vector2.Angle(Vector2.right, current_dir);
        Vector3 cross = Vector3.Cross(transform.localScale, current_dir);

        if (cross.x > 0)
        {
            rotation = -rotation;
        }

        rotation_vec = Quaternion.Euler(0, 0, rotation);


        if (!chargedShooting)
        {
            if (Input.GetButton("Fire1"))
            {
                if (startTimer >= startCharge)
                {
                    isCharging = true;
                    anim.SetBool("charging", true);
                    maxSpeed = S_MAXSPEED;
                    charge_go.SetActive(true);
                    if (!charged)
                    {
                        if (chargeTimer >= maxChargeTime)
                        {
                            charged = true;
                            chargeBar.GetComponent<Animator>().SetBool("charged", true);
                            return;
                        }
                        chargeTimer += Time.deltaTime;
                        chargeBar.fillAmount = chargeTimer / maxChargeTime;                
                    }
                }
            }
            else
            {
                if (startTimer >= startCharge && !isCharging)
                {
                    startTimer = 0;
                    chargeTimer = 0;
                    charged = false;
                }
            }
            startTimer += Time.deltaTime;
        }
        else
        {
            if (canShield)
            {
                isShooting = false;
                anim.SetBool("isShooting", false);
                if (double_damage)
                {
                    Player1ChargeAttack();
                }
                chargeShot();
            }
            chargedCounter += Time.deltaTime;
        }

        if (Input.GetButtonUp("Fire1"))
        {
            isCharging = false;
            anim.SetBool("charging", false);
            maxSpeed = N_MAXSPEED;
            if (charged)
            {
                chargeShot();
                chargedShooting = true;
                canShoot = true;
                chargeBar.GetComponent<Animator>().SetBool("charged",false);
            }
            else if(canShoot)
            {
                if (rotation == 45 || rotation == -45 || rotation == 135 || rotation == -135)
                {
                    velocity = new Vector2(50, 50);
                    offset = new Vector2(3.5f, 2.5f);
                }
                else if (rotation == 90 || rotation == -90)
                {
                    velocity = new Vector2(0, 100);
                    offset = new Vector2(0.0f, 4.0f);
                }
                else if (rotation == 0 || rotation == 180)
                {
                    velocity = new Vector2(100, 0);
                }

                if (isShooting)
                {
                    anim.SetTrigger("shootAgain");
                }
                isShooting = true;
                anim.SetBool("isShooting",true);
                if (grounded)
                {
                    rb2d.velocity = Vector2.zero;   
                }
                GameObject go = (GameObject)Instantiate(projectile, new Vector2(transform.position.x + offset.x * transform.localScale.x, transform.position.y + offset.y), rotation_vec); 
                go.GetComponent<Rigidbody2D>().velocity = new Vector2(transform.localScale.x * velocity.x, current_dir.y * velocity.y);
            }
            canShoot = false;
            chargeTimer = 0;
            reloadTimer = 0;
            chargeBar.fillAmount = chargeTimer / maxChargeTime;
            charge_go.SetActive(false);
            startTimer = 0;
        }

    }

    void FixedUpdate()
    {
        Vector3 easeVelocity = rb2d.velocity;
        easeVelocity.y = rb2d.velocity.y;
        easeVelocity.z = 0.0f;
        easeVelocity.x *= 0.75f;

        if (Input.GetKey(KeyCode.E))
        {
            return;
        }
        if (isShooting)
        {
            return;
        }
        canShoot = true;
       //move player
        float h = Input.GetAxis("Horizontal");

        if (h == 0)
        {
            rb2d.velocity = new Vector2(h, rb2d.velocity.y);
        }


        if (grounded)
        {
            //rb2d.velocity = easeVelocity;
        }

        rb2d.AddForce((Vector2.right * speed) * h);

        //Limiting the speed
        if (rb2d.velocity.x > maxSpeed)
        {
            rb2d.velocity = new Vector2(maxSpeed, rb2d.velocity.y);
        }
        else if (rb2d.velocity.x < -maxSpeed)
        {
            rb2d.velocity = new Vector2(-maxSpeed, rb2d.velocity.y);
        }

        if (Input.GetAxis("Horizontal") == 0)
        {
            
        }

        //jump balacing gravity
        if (rb2d.velocity.y < 0)
        {
            rb2d.velocity += Vector2.up * Physics2D.gravity.y * (fallMultiplier - 1) * Time.deltaTime;
        }
        else if (rb2d.velocity.y > 0 && !Input.GetButton("Jump"))
        {
            rb2d.velocity += Vector2.up * Physics2D.gravity.y * (lowJumpMultiplier - 1) * Time.deltaTime;
        }

    }

    public void DoubleUp(){
        //FALTA FAZER DOUBLE DAMAGE OU WTV AS BULLET SE FOR POWER DA SHIT
        double_damage = true;
        double_d.SetActive(true);
        return;
        
    }
    public void deathTrigger(){
        if (Time.timeScale == 0) {
            return;
        }
        if (chargedShooting)
        {
            return;
        }
        dead = true;
        anim.SetBool("dead", dead);
        double_d.SetActive(false);
        //gameObject.GetComponent<PauseTime>().SlowDown();
    }

    public void reviveTrigger(){
        dead = false;
        anim.SetBool("dead", dead);
        gameObject.GetComponent<PauseTime>().Normal();
    }

    void OnTriggerEnter2D(Collider2D col){
        //Debug.Log(col.gameObject.tag);
        if (col.gameObject.tag == "EnemyBullet")
        {
            if (isCharging && col.gameObject.transform.localScale.x.Equals(gameObject.transform.localScale.x))
            {
                    anim.SetTrigger("blocked");
            }
            else
            {
                deathTrigger();
                deathBullet = col.gameObject;
            }
        }
    }

    void chargeShot(){
        if (chargedCounter > chargedNum)
        {
            p1chargedCounter = 0;
            chargedCounter = 0;
            chargeTimer = 0;
            reloadTimer = 0;
            chargedShooting = false;
            shield.SetActive(false);

        }
        else
        {
            shield.SetActive(true);
            canShoot = true;
            charged = false;
        }

        chargeTimer -= Time.deltaTime;
        chargeBar.fillAmount = chargeTimer / maxChargeTime;
        reloadTimer = 0;
        canShield = false;
    }

    public void setShoot(bool _canShoot){
        canShoot = _canShoot;
    }

    public void NotShooting(){
        isShooting = false;
        anim.SetBool("isShooting", false);
    }

    public void Player1ChargeAttack(){
        
        if (p1chargedCounter > p1chargeNum)
        {
            return;
        }
        if (rotation == 45 || rotation == -45 || rotation == 135 || rotation == -135)
        {
            velocity = new Vector2(50, 50);
            offset = new Vector2(1.5f,2.5f);
            velocity2 = new Vector2(25,75);
            offset2 = new Vector2(1.5f,4.0f);
            velocity3 = new Vector2(75,25);
            offset3 = new Vector2(1.5f,2.5f);
        }
        else if (rotation == 90 || rotation == -90)
        {
            velocity = new Vector2(0, 100);
            offset = new Vector2(0,4.0f);
            velocity2 = new Vector2(-25,75);
            offset2 = new Vector2(0,4f);
            velocity3 = new Vector2(25,75);
            offset3 = new Vector2(0,4f);

        }
        else if (rotation == 0 || rotation == 180){
            velocity = new Vector2(100, 0);
            offset = new Vector2(1.0f,1.0f);
            velocity2 = new Vector2(75,-25);
            offset2 = new Vector2(2.5f,1f);
            velocity3 = new Vector2(75,25);
            offset3 = new Vector2(2.5f,1f);
        }
        GameObject go = (GameObject)Instantiate(projectile, new Vector2(transform.position.x + offset.x * transform.localScale.x, transform.position.y + offset.y),rotation_vec); 
        go.GetComponent<Rigidbody2D>().velocity = new Vector2(transform.localScale.x *velocity.x, transform.localScale.y * velocity.y);

        go = (GameObject)Instantiate(projectile, new Vector2(transform.position.x + offset2.x * transform.localScale.x, transform.position.y + offset2.y),rotation_vec);
        go.GetComponent<Rigidbody2D>().velocity = new Vector2(transform.localScale.x *velocity2.x, transform.localScale.y * velocity2.y);

        go = (GameObject)Instantiate(projectile, new Vector2(transform.position.x + offset3.x * transform.localScale.x, transform.position.y + offset3.y),rotation_vec);
        go.GetComponent<Rigidbody2D>().velocity = new Vector2(transform.localScale.x * velocity3.x, transform.localScale.y * velocity3.y);

        reloadTimer = 0;
        ++ p1chargedCounter;
        canShoot = false;
    }
}
