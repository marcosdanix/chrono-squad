﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LivesController : MonoBehaviour {

    public int lives;

	// Use this for initialization
	void Start () {
        lives = 15;
	}
	
	// Update is called once per frame
	void Update () {
        if (lives <= 0)
        {
            //GAME OVER
        }
	}

    void OnGUI(){
        GUI.skin.box.fontSize = 20;
        GUI.Box(new Rect(100, 20, 40, 30), "x"+lives.ToString());
    }

    public void died(){
        lives -= 1;
    }
}
