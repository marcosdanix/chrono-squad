﻿using UnityEngine;

public class GhostPointInTime{

    public Vector3 position;
    public Vector3 rotation;
    public bool grounded;
    public bool dead;
    public bool isCharging;
    public bool chargedShooting;

    public GhostPointInTime (Vector3 _position, Vector3 _rotation, bool _grounded, bool _dead, bool _isCharging, bool _chargedShooting){

        position = _position;
        rotation = _rotation;
        grounded = _grounded;
        dead = _dead;
        isCharging = _isCharging;
        chargedShooting = _chargedShooting;

    }
}

