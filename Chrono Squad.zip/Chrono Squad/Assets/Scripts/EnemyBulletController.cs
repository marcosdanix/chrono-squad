﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBulletController : MonoBehaviour {

    Rigidbody2D rb;
    Vector3 init_position;
    public bool dead = false;
    Animator anim;


    // Use this for initialization
    void Start () {
        rb = gameObject.GetComponent<Rigidbody2D>();
        init_position = gameObject.transform.position;

        anim = gameObject.GetComponentInChildren<Animator>();
    }

    // Update is called once per frame
    void Update () {
        if (Input.GetKey(KeyCode.E))
        {

        }

    }

    void OnTriggerEnter2D(Collider2D col){

        if (col.gameObject.tag == "EnemyRange")
        {
            anim.SetBool("stop", true);
        }

        if (col.gameObject.tag == "Player")
        {
            //anim.SetBool("stop", true);
            rb.velocity = Vector2.zero;
            //col.gameObject.GetComponent<Player1Controller>().deathTrigger();
        }

        if (col.gameObject.tag == "Shield")
        {
            rb.velocity = new Vector2(50, 50);
        }

//        if(col.gameObject.tag == "GhostPlayer")
//        {
//            rb.velocity = Vector2.zero;
//            col.gameObject.GetComponent<GhostReplay>().deathTrigger();
//        }


    }

    void OnTriggerExit2D(Collider2D col){
        if (col.gameObject.tag == "EnemyRange")
        {
            rb.velocity = Vector2.zero;
            anim.SetBool("stop", true);
            gameObject.GetComponent<BoxCollider2D>().enabled = false;
        }
    }
}
