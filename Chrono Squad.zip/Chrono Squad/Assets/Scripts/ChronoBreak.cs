﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
public class ChronoBreak : MonoBehaviour
{
    List<GhostPointInTime> playerPosition= new List<GhostPointInTime>();
    List<GhostPointInTime> savedPosition= new List<GhostPointInTime>();


    List<Vector3> positionVal = new List<Vector3>();

    List<GhostPointInTime> rewindPositions = new List<GhostPointInTime>();

    List<Vector3> rotationRewind = new List<Vector3>();
    List<Vector3> rotationVal = new List<Vector3>();

    public GameObject player2;

    int indexVal;
    public float counter;
    bool isRewinding;
    int timeLimitInSeconds =10;
    private MainTimeController timeController;
    public PlayerAnimation playerAnim;
    public Player1Controller playerController;
    public GameObject ghostObject;
    public GameObject char_select;
    bool player_died;
    bool selecting_char = false;
    public GameObject Lives;

    void Start()
    {
        timeController = gameObject.GetComponent<MainTimeController>();
        playerAnim = gameObject.GetComponentInChildren<PlayerAnimation> ();
        playerController = gameObject.GetComponent<Player1Controller>();

    }

    public void Populate(List<GhostPointInTime> revivePositions){
//        playerPosition = revivePositions;
//        savedPosition = revivePositions;
//        indexVal = revivePositions.Count;
    }
    void Update()
    {
        if (selecting_char)
        {
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                char_select.SetActive(false);
                selecting_char = false;
                gameObject.GetComponent<PauseTime>().Pause();
                return;
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                char_select.SetActive(false);   
                GameObject newPlayer = Instantiate(player2,transform.position, Quaternion.identity);
                newPlayer.GetComponent<ChronoBreak_P2>().Populate(savedPosition);
                gameObject.GetComponent<PauseTime>().Pause();
                Destroy(gameObject);
            }
        }

        //we use a counter variable to limit the rewind mechanic usage to 10 seconds
        if(Input.GetKey(KeyCode.E))
        {
            playerAnim.rewind = -1.0f;
            if (counter > 0) {
                counter -= Time.deltaTime;
                isRewinding = true;
                Rewind ();
            } 
            if (counter <= 0) {
                //Rewind();
            }

        }
        else
        {
            
            if (Input.GetKeyUp(KeyCode.E))
            {
                
            }

            if (Input.GetKeyDown(KeyCode.R))
            {

                char_select.SetActive(true);
                selecting_char = true;
                Restart();
            }

            if(counter<timeLimitInSeconds)
            {
                counter+=Time.deltaTime;
            }
            playerAnim.rewind = 1.0f;
            isRewinding = false;

        }
        //if time is moving forward, keep adding new elements to the arrays
        if (!isRewinding) {
            if (Time.timeScale == 0) {
                return;
            }
            playerPosition.Insert(0, new GhostPointInTime(transform.position,transform.localScale,playerController.grounded,playerController.dead,playerController.isCharging, playerController.chargedShooting));
            savedPosition.Insert(0, playerPosition[0]);
            if (playerController.dead)
            {
                player_died = true;
            }



                   


//            positionVal.Add (transform.position);
//            rotationVal.Add (transform.localScale);

            //timeController.addPlayerMovement(gameObject,positionVal);

            //increase the index every frame
            indexVal++;

        }
    }
    //method that actually 'rewinds' the game
    void Rewind()
    {
        //if current index is not 0
        if (playerPosition.Count > 0)
        {
            //decrease index

            //get last data of this gameobject and apply it to the gameobject
            //remove the used data thereby decreasing the list size
            GhostPointInTime pointInTime = playerPosition[0];
            rewindPositions.Insert(0,pointInTime);
            transform.position = pointInTime.position;
            transform.localScale = pointInTime.rotation;
            if (pointInTime.isCharging)
            {
                playerController.charge_go.SetActive(true);
            }
            else
            {
                playerController.charge_go.SetActive(false);
            }
            if (pointInTime.chargedShooting)
            {
                playerController.shield.SetActive(true);
            }
            else
            {
                playerController.shield.SetActive(false);
            }


            playerPosition.RemoveAt(0);
//            rewindVal.Add(positionVal[indexVal - 1]);
//            transform.position = positionVal[indexVal - 1];
//            positionVal.RemoveAt(indexVal - 1);
//            rotationRewind.Add(rotationVal[indexVal - 1]);
//            transform.localScale = rotationVal[indexVal - 1];
//            rotationVal.RemoveAt(indexVal - 1);
        }
        indexVal--;

    }

    void Restart(){
        ghostObject = Instantiate(ghostObject,transform.position, Quaternion.identity);
        GhostContoller ghostS = ghostObject.GetComponentInChildren(typeof(GhostContoller)) as GhostContoller;
        ghostS.populate(player_died,playerController.deathBullet);
        player_died = false;
        playerController.deathBullet = null;
        GhostChronoBreak script = ghostObject.GetComponent(typeof(GhostChronoBreak)) as GhostChronoBreak;
        script.Populate(rewindPositions);
        rewindPositions = new List<GhostPointInTime>();
        Lives.GetComponent<LivesController>().died();
    }
}
