﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player1Controller : MonoBehaviour {

	public bool facingRight = true;
	public bool jump = false;

    public float maxSpeed = 300f;
	public float speed = 300f; 
    public float jumpForce;
	public Transform groundCheck;

    public float fallMultiplier = 2.5f;
    public float lowJumpMultiplier = 2f;

    public float chargeTimer = 0;
    public float maxChargeTime = 2f;

	public bool grounded = false;
    public bool dead = false;
	private Animator anim;
	private Rigidbody2D rb2d;

    //shoot
    public GameObject projectile;
    public Vector2 velocity;
    Vector2 offset;
    Vector2 current_dir= Vector2.zero;
    int rotation;
    public Quaternion rotation_vec = Quaternion.identity;
    bool charged= false;
    public Image chargeBar;
    public bool chargedShooting = false;
    Vector2 velocity2;
    Vector2 velocity3;
    Vector2 offset2;
    Vector2 offset3;
    bool canShoot = false;
    float reloadTimer;
    public GameObject charge_go;
    public int chargedNum = 10;
    public int chargedCounter = 0;
    public GameObject double_d;
    public bool double_damage = false;
    public bool isShooting = false;
    public bool isCharging = false;

    public GameObject shield;
    int p2chargeCounter;
    public GameObject deathBullet;

    float bossFightInitialPosition = 388;

    public bool bossFightStarted = false;

	// Use this for initialization
	void Start () {
        rb2d = gameObject.GetComponent<Rigidbody2D>();
        anim = gameObject.GetComponentInChildren<Animator>();
        chargeTimer = 0;
        reloadTimer = 0;
	}

    void Update ()
    {
        isShooting = false;
        if (Time.timeScale == 0) {
            return;
        }

        offset = new Vector2(1.0f,1.0f);
        current_dir = Vector2.zero;

        if (Input.GetKey (KeyCode.E)) {
            return;
        } 

        if (Input.GetAxis("Horizontal") < -0.1f)
        {
            transform.localScale = new Vector3(-1, 1, 1);
            current_dir += Vector2.left;
        }
        if (Input.GetAxis("Horizontal") > 0.1)
        {
            transform.localScale = new Vector3(1, 1, 1);
            current_dir += Vector2.right;
        }

        if (Input.GetAxis("Vertical") < -0.1f && !grounded)
        {
            //transform.localScale = new Vector3(1, -1, 1);
            current_dir += Vector2.down;
        }
        if (Input.GetAxis("Vertical") > 0.1)
        {
            //transform.localScale = new Vector3(1, 1, 1);
            current_dir += Vector2.up;
        }

        if (Input.GetButtonDown("Jump") && grounded)
        {
            
             rb2d.AddForce(Vector2.up * Mathf.Sqrt(-2.0f * Physics2D.gravity.y * jumpForce), ForceMode2D.Impulse);
        }

        // ATTACKING
        if (reloadTimer >= 0.1f)
        {
            canShoot = true;
        }
        else{
            canShoot = false;
            reloadTimer += Time.deltaTime;
        }

        if (current_dir == Vector2.zero)
        {
            current_dir = new Vector2(transform.localScale.x, 0);
        }

        rotation = (int)Vector2.Angle(Vector2.right, current_dir);
        Vector3 cross = Vector3.Cross(transform.localScale, current_dir);

        if (cross.x > 0)
        {
            rotation = -rotation;
        }

        rotation_vec = Quaternion.Euler(0, 0, rotation);


        if (!chargedShooting)
        {
            if (Input.GetButton("Fire1"))
            {
                isCharging = true;
                charge_go.SetActive(true);
                if (!charged)
                {
                    if (chargeTimer >= maxChargeTime)
                    {
                        charged = true;
                        chargeBar.GetComponent<Animator>().SetBool("charged",true);
                        return;
                    }
                    chargeTimer += Time.deltaTime;
                    chargeBar.fillAmount = chargeTimer / maxChargeTime;                
                }
            }

            if (Input.GetButtonUp("Fire1") && canShoot)
            {

                if (charged)
                {
                    if (double_damage)
                    {
                        //Player2ChargeAttack();
                    }
                    chargeShot();
                    chargedShooting = true;
                    chargeBar.GetComponent<Animator>().SetBool("charged",false);
                }
                else
                {
                    if (rotation == 45 || rotation == -45 || rotation == 135 || rotation == -135)
                    {
                        velocity = new Vector2(50, 50);
                        offset = new Vector2(1.5f, 2.5f);
                    }
                    else if (rotation == 90 || rotation == -90)
                    {
                        velocity = new Vector2(0, 100);
                        offset = new Vector2(0.0f, 4.0f);
                    }
                    else if (rotation == 0 || rotation == 180)
                    {
                        velocity = new Vector2(100, 0);
                    }
                    isShooting = true;
                    GameObject go = (GameObject)Instantiate(projectile, new Vector2(transform.position.x + offset.x * transform.localScale.x, transform.position.y + offset.y), rotation_vec); 
                    go.GetComponent<Rigidbody2D>().velocity = new Vector2(transform.localScale.x * velocity.x, current_dir.y * velocity.y);
                }
                canShoot = false;
                chargeTimer = 0;
                reloadTimer = 0;
                chargeBar.fillAmount = chargeTimer / maxChargeTime;
                isCharging = false;
                charge_go.SetActive(false);
            }
        }
        else
        {
            if (canShoot)
            {
                chargeShot();
            }
        }
    }

    void FixedUpdate()
    {
        Vector3 easeVelocity = rb2d.velocity;
        easeVelocity.y = rb2d.velocity.y;
        easeVelocity.z = 0.0f;
        easeVelocity.x *= 0.75f;

        if (Input.GetKey (KeyCode.E)) {
            return;
        }
        if (dead)
        {
            return;
        }
       //move player
        float h = Input.GetAxis("Horizontal");

        if (h == 0)
        {
            rb2d.velocity = new Vector2(h, rb2d.velocity.y);
        }


        if (grounded)
        {
            //rb2d.velocity = easeVelocity;
        }

        rb2d.AddForce((Vector2.right * speed) * h);

        //Limiting the speed
        if (rb2d.velocity.x > maxSpeed)
        {
            rb2d.velocity = new Vector2(maxSpeed, rb2d.velocity.y);
        }
        else if (rb2d.velocity.x < -maxSpeed)
        {
            rb2d.velocity = new Vector2(-maxSpeed, rb2d.velocity.y);
        }

        if (Input.GetAxis("Horizontal") == 0)
        {
            
        }

        //jump balacing gravity
        if (rb2d.velocity.y < 0)
        {
            rb2d.velocity += Vector2.up * Physics2D.gravity.y * (fallMultiplier - 1) * Time.deltaTime;
        }
        else if (rb2d.velocity.y > 0 && !Input.GetButton("Jump"))
        {
            rb2d.velocity += Vector2.up * Physics2D.gravity.y * (lowJumpMultiplier - 1) * Time.deltaTime;
        }

    }

    public void DoubleUp(){
        //FALTA FAZER DOUBLE DAMAGE OU WTV AS BULLET SE FOR POWER DA SHIT
        double_d.SetActive(true);
        return;
        
    }
    public void deathTrigger(){
        if (Time.timeScale == 0) {
            return;
        }
        dead = true;
        anim.SetBool("dead", dead);
        double_d.SetActive(false);
        //gameObject.GetComponent<PauseTime>().SlowDown();
    }

    public void reviveTrigger(){
        dead = false;
        anim.SetBool("dead", dead);
        gameObject.GetComponent<PauseTime>().Normal();
    }

    void OnTriggerEnter2D(Collider2D col){
        if (col.gameObject.tag == "EnemyBullet")
        {
            deathTrigger();
            deathBullet = col.gameObject;
        }
        else if (col.gameObject.tag == "Enemy_Missile")
        {
            deathTrigger();
            deathBullet = col.gameObject;
        }
        else if( (col.gameObject.tag == "MainCamera") && bossFightStarted) //stop the player from moving outside of the camera during boss battles
        {
            float leftBorder = bossFightInitialPosition - 25;
            float rightBorder = bossFightInitialPosition + 25;
            transform.position = (new Vector3 (Mathf.Clamp(transform.position.x, leftBorder, rightBorder), transform.position.y, transform.position.z));
        }
    }

    void chargeShot(){
        if (chargedCounter > chargedNum)
        {
            chargedCounter = 0;
            chargeTimer = 0;
            reloadTimer = 0;
            chargedShooting = false;
            charged = false;
        }
        if (rotation == 45 || rotation == -45 || rotation == 135 || rotation == -135)
        {
            velocity = new Vector2(50, 50);
            offset = new Vector2(1.5f,2.5f);
            velocity2 = new Vector2(25,75);
            offset2 = new Vector2(1.5f,4.0f);
            velocity3 = new Vector2(75,25);
            offset3 = new Vector2(1.5f,2.5f);
        }
        else if (rotation == 90 || rotation == -90)
        {
            velocity = new Vector2(0, 100);
            offset = new Vector2(0,4.0f);
            velocity2 = new Vector2(-25,75);
            offset2 = new Vector2(0,4f);
            velocity3 = new Vector2(25,75);
            offset3 = new Vector2(0,4f);

        }
        else if (rotation == 0 || rotation == 180){
            velocity = new Vector2(100, 0);
            offset = new Vector2(1.0f,1.0f);
            velocity2 = new Vector2(75,-25);
            offset2 = new Vector2(2.5f,1f);
            velocity3 = new Vector2(75,25);
            offset3 = new Vector2(2.5f,1f);
        }
        GameObject go = (GameObject)Instantiate(projectile, new Vector2(transform.position.x + offset.x * transform.localScale.x, transform.position.y + offset.y),rotation_vec); 
        go.GetComponent<Rigidbody2D>().velocity = new Vector2(transform.localScale.x *velocity.x, transform.localScale.y * velocity.y);

        go = (GameObject)Instantiate(projectile, new Vector2(transform.position.x + offset2.x * transform.localScale.x, transform.position.y + offset2.y),rotation_vec); 
        go.GetComponent<Rigidbody2D>().velocity = new Vector2(transform.localScale.x *velocity2.x, transform.localScale.y * velocity2.y);

        go = (GameObject)Instantiate(projectile, new Vector2(transform.position.x + offset3.x * transform.localScale.x, transform.position.y + offset3.y),rotation_vec);
        go.GetComponent<Rigidbody2D>().velocity = new Vector2(transform.localScale.x * velocity3.x, transform.localScale.y * velocity3.y);

        chargeTimer -= Time.deltaTime;
        chargeBar.fillAmount = chargeTimer / maxChargeTime;
        ++chargedCounter;
        reloadTimer = 0;
        canShoot = false;
    }

    void Player2ChargeAttack(){
        if (p2chargeCounter > chargedNum)
        {
            shield.SetActive(false);

        }
        else
        {
            shield.SetActive(true);
            canShoot = true;
            charged = false;
        }

        chargeTimer -= Time.deltaTime;
        chargeBar.fillAmount = chargeTimer / maxChargeTime;
        reloadTimer = 0;
        ++p2chargeCounter;
    }

}
